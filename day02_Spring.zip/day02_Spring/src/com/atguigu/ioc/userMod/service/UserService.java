package com.atguigu.ioc.userMod.service;

public interface UserService {

	void addUser();
	
}
