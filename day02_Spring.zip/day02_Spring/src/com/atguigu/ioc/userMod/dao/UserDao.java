package com.atguigu.ioc.userMod.dao;

public interface UserDao {

	void addUser();
	
}
