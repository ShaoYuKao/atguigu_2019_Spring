package com.atguigu.ioc.auto;

public interface DeptI {

}
