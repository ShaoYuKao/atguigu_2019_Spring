package com.atguigu.spring.mod;

public class Test {

	public static void main(String[] args) {
		
		Person person = new Person();
		person.setId(1001);
		person.setName("张三");
		System.out.println(person);
		
	}
	
}
