package com.atguigu.ioc.auto;

public class CarExtends {

}
