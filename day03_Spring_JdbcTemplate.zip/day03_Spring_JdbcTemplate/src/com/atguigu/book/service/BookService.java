package com.atguigu.book.service;

public interface BookService {

	void buyBook(String bid, String uid);
	
}
