package com.atguigu.book_xml.service;

public interface BookService {

	void buyBook(String bid, String uid);
	
}
